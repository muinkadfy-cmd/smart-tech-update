import { app, BrowserWindow, ipcMain, dialog, shell } from 'electron';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import https from 'https';
import http from 'http';
import { promisify } from 'util';
import { spawn } from 'child_process';
import extractZip from 'extract-zip';
import * as updateManager from './updateManager.js';
import * as updater from './updater.js';
import * as storageHandler from './storage-handler.js';

const readdir = promisify(fs.readdir);
const stat = promisify(fs.stat);
const unlink = promisify(fs.unlink);
// Usar fs.promises.rm que é a versão moderna (substitui rmdir)
const rm = fs.promises.rm || promisify(fs.rmdir);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Detectar modo de desenvolvimento vs produção
const isDev = process.env.NODE_ENV === 'development' || 
              process.env.ELECTRON_IS_DEV === '1' ||
              !app.isPackaged;

// Caminho para salvar preferências da janela
const userDataPath = app.getPath('userData');
const windowStatePath = path.join(userDataPath, 'window-state.json');

// Carregar estado salvo da janela
function loadWindowState() {
  try {
    if (fs.existsSync(windowStatePath)) {
      const data = fs.readFileSync(windowStatePath, 'utf8');
      return JSON.parse(data);
    }
  } catch (error) {
    // Erro silencioso em produção
    if (isDev) console.warn('Erro ao carregar estado da janela:', error);
  }
  return null;
}

// Salvar estado da janela
function saveWindowState(win) {
  try {
    const state = {
      width: win.getSize()[0],
      height: win.getSize()[1],
      x: win.getPosition()[0],
      y: win.getPosition()[1],
      isMaximized: win.isMaximized(),
      isFullScreen: win.isFullScreen(),
    };
    fs.writeFileSync(windowStatePath, JSON.stringify(state, null, 2));
  } catch (error) {
    // Erro silencioso em produção
    if (isDev) console.warn('Erro ao salvar estado da janela:', error);
  }
}

function createWindow() {
  const savedState = loadWindowState();
  const defaultWidth = 1400;
  const defaultHeight = 900;
  const minWidth = 1000;
  const minHeight = 600;

  const win = new BrowserWindow({
    width: savedState?.width || defaultWidth,
    height: savedState?.height || defaultHeight,
    x: savedState?.x,
    y: savedState?.y,
    minWidth: minWidth,
    minHeight: minHeight,
    fullscreen: savedState?.isFullScreen || false,
    resizable: true,
    minimizable: true,
    maximizable: true,
    fullscreenable: true,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      // Preload script: caminho correto para dev e produção
      preload: (() => {
        if (isDev) {
          return path.join(__dirname, 'preload.js');
        } else {
          // Em produção, o preload está em app.asar.unpacked conforme configurado no package.json
          const preloadPath = path.join(process.resourcesPath, 'app.asar.unpacked', 'electron', 'preload.js');
          // Fallback: tentar também no diretório do app
          if (!fs.existsSync(preloadPath)) {
            const fallbackPath = path.join(__dirname, 'preload.js');
            if (fs.existsSync(fallbackPath)) {
              return fallbackPath;
            }
          }
          return preloadPath;
        }
      })(),
      webSecurity: false,
      zoomFactor: 1.0, // Zoom padrão
    },
    title: 'Smart Tech Rolândia 2.0',
    backgroundColor: '#1a1f2e',
    show: false, // Não mostrar até estar pronto
  });

  // Restaurar estado maximizado se estava maximizado
  if (savedState?.isMaximized && !savedState?.isFullScreen) {
    win.maximize();
  }

  // Mostrar janela quando estiver pronta
  win.once('ready-to-show', () => {
    win.show();
  });

  // Salvar estado ao redimensionar/mover
  let saveStateTimeout;
  const debounceSave = () => {
    clearTimeout(saveStateTimeout);
    saveStateTimeout = setTimeout(() => {
      if (!win.isDestroyed()) {
        saveWindowState(win);
      }
    }, 500);
  };

  win.on('resize', debounceSave);
  win.on('move', debounceSave);
  win.on('maximize', () => saveWindowState(win));
  win.on('unmaximize', () => saveWindowState(win));
  win.on('enter-full-screen', () => saveWindowState(win));
  win.on('leave-full-screen', () => saveWindowState(win));

  // Injetar CSS para ocultar scrollbars após carregar a página
  // E verificar se o preload foi carregado corretamente
  win.webContents.on('did-finish-load', () => {
    // Verificar se o preload foi carregado (apenas em dev para debug)
    if (isDev) {
      win.webContents.executeJavaScript(`
        console.log('Preload disponível:', typeof window.electron !== 'undefined');
        console.log('Electron detectado:', window.electron?.isElectron === true);
      `).catch(() => {
        // Ignorar erros silenciosamente
      });
    }
    
    win.webContents.insertCSS(`
      * {
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      *::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
        background: transparent !important;
        opacity: 0 !important;
        visibility: hidden !important;
        appearance: none !important;
        -webkit-appearance: none !important;
        pointer-events: none !important;
      }
      *::-webkit-scrollbar-track,
      *::-webkit-scrollbar-thumb,
      *::-webkit-scrollbar-corner,
      *::-webkit-scrollbar-button {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
        background: transparent !important;
        opacity: 0 !important;
        visibility: hidden !important;
        appearance: none !important;
        -webkit-appearance: none !important;
        pointer-events: none !important;
      }
      html, body {
        overflow-x: hidden !important;
        scrollbar-width: none !important;
        -ms-overflow-style: none !important;
      }
      html::-webkit-scrollbar,
      body::-webkit-scrollbar {
        display: none !important;
        width: 0 !important;
        height: 0 !important;
      }
    `);
  });

  // Permitir toggle de fullscreen com F11 e ESC
  // F11: alterna fullscreen
  // ESC: sai do fullscreen (se estiver em fullscreen)
  // Ctrl + Plus/Minus: zoom in/out
  // Ctrl + 0: reset zoom
  
  win.webContents.on('before-input-event', (event, input) => {
    // F11: toggle fullscreen
    if (input.key === 'F11') {
      event.preventDefault();
      const isFullScreen = win.isFullScreen();
      win.setFullScreen(!isFullScreen);
      saveWindowState(win);
    }
    // ESC: sai do fullscreen se estiver em fullscreen
    if (input.key === 'Escape' && win.isFullScreen()) {
      event.preventDefault();
      win.setFullScreen(false);
      saveWindowState(win);
    }
    // Ctrl + Plus: zoom in
    if (input.control && (input.key === '+' || input.key === '=')) {
      event.preventDefault();
      const currentZoom = win.webContents.getZoomLevel();
      win.webContents.setZoomLevel(Math.min(currentZoom + 0.5, 5));
    }
    // Ctrl + Minus: zoom out
    if (input.control && input.key === '-') {
      event.preventDefault();
      const currentZoom = win.webContents.getZoomLevel();
      win.webContents.setZoomLevel(Math.max(currentZoom - 0.5, -3));
    }
    // Ctrl + 0: reset zoom
    if (input.control && input.key === '0') {
      event.preventDefault();
      win.webContents.setZoomLevel(0);
    }
  });

  // Carregar a aplicação
  if (isDev) {
    win.loadURL('http://localhost:8081');
    win.webContents.openDevTools();
  } else {
    // No modo de produção empacotado, os arquivos estão dentro de app.asar
    // app.getAppPath() retorna o caminho para app.asar
    const appPath = app.getAppPath();
    const indexPath = path.join(appPath, 'dist', 'index.html');
    
    // PRODUÇÃO: Não abrir DevTools
    // win.webContents.openDevTools(); // REMOVIDO PARA PRODUÇÃO
    
    // Usar loadFile que funciona melhor com caminhos relativos
    win.loadFile(indexPath).catch((err) => {
      // Em produção, apenas tentar fallback sem logs excessivos
      const fileUrl = `file://${indexPath.replace(/\\/g, '/')}`;
      win.loadURL(fileUrl);
    });
  }

  // Garantir que NODE_ENV está definido como production
  if (!isDev) {
    process.env.NODE_ENV = 'production';
  }

  // Remover menu bar
  win.setMenuBarVisibility(false);
}

/**
 * Verifica atualizações manualmente ao iniciar o app
 * Busca SOMENTE do endpoint remoto do GitHub
 * Mostra diálogo se houver nova versão disponível
 */
function checkForUpdatesManual() {
  // Apenas verificar em produção (não em desenvolvimento)
  if (isDev) {
    console.log('[Update Check] Modo desenvolvimento - verificação manual desabilitada');
    return;
  }

  const currentVersion = app.getVersion();
  // Endpoint remoto: version.json (MODO 1 - UPDATE ASSISTIDO)
  const url = 'https://raw.githubusercontent.com/muinkadfy-cmd/smart-tech-update/main/update/version.json';

  console.log(`[Update Check] Verificando atualizações... Versão atual: ${currentVersion}`);

  https.get(url, (res) => {
    let data = '';

    res.on('data', (chunk) => (data += chunk));
    res.on('end', () => {
      try {
        const versionInfo = JSON.parse(data);

        // Validar: se version > app.getVersion() → mostrar atualização disponível
        // NUNCA comparar como string, sempre usar semver
        const compareResult = compareVersionsSemver(currentVersion, versionInfo.version);

        if (compareResult < 0) {
          // Nova versão disponível (version > currentVersion)
          console.log(`[Update Check] Nova versão disponível: ${versionInfo.version} > ${currentVersion}`);
          
          // Buscar update.json para obter downloadUrl e changelog
          const updateUrl = 'https://raw.githubusercontent.com/muinkadfy-cmd/smart-tech-update/main/update/update.json';
          https.get(updateUrl, (updateRes) => {
            let updateData = '';
            updateRes.on('data', (chunk) => (updateData += chunk));
            updateRes.on('end', () => {
              try {
                const update = JSON.parse(updateData);
                
                const mainWindow = BrowserWindow.getAllWindows()[0];
                if (mainWindow && !mainWindow.isDestroyed()) {
                  dialog.showMessageBox(mainWindow, {
                    type: 'info',
                    buttons: ['Atualizar agora', 'Depois'],
                    title: 'Atualização disponível',
                    message: `Nova versão ${versionInfo.version} disponível`,
                    detail: `Versão atual: ${currentVersion}\n\nVersão ${versionInfo.version}\n${(update.changelog || []).map(item => `• ${item}`).join('\n') || '• Melhorias de performance\n• Correções de bugs\n• Atualizações de segurança\n• Otimizações gerais'}`
                  }).then((result) => {
                    if (result.response === 0) {
                      // Usuário escolheu "Atualizar agora" - iniciar download assistido
                      if (update.downloadUrl) {
                        console.log('[Update Check] Usuário escolheu "Atualizar agora"');
                        console.log('[Update Check] Iniciando download assistido...');
                        console.log('[Update Check] URL:', update.downloadUrl);
                        
                        const mainWindow = BrowserWindow.getAllWindows()[0];
                        if (mainWindow && !mainWindow.isDestroyed()) {
                          // Enviar evento para o renderer iniciar o download assistido
                          // O listener no renderer vai chamar handleDownloadUpdateWithUrl automaticamente
                          mainWindow.webContents.send('update-available', {
                            version: versionInfo.version,
                            downloadUrl: update.downloadUrl,
                            changelog: update.changelog
                          });
                        }
                      } else {
                        console.error('[Update Check] downloadUrl não encontrado no update.json');
                        const mainWindow = BrowserWindow.getAllWindows()[0];
                        if (mainWindow && !mainWindow.isDestroyed()) {
                          dialog.showErrorBox(
                            'Erro na Atualização',
                            'URL de download não encontrada. Por favor, verifique a aba de Atualização para mais informações.'
                          );
                        }
                      }
                    } else {
                      console.log('[Update Check] Usuário escolheu "Depois"');
                    }
                  }).catch((err) => {
                    console.error('[Update Check] Erro ao mostrar diálogo:', err);
                  });
                }
              } catch (err) {
                console.error('[Update Check] Erro ao processar update.json:', err);
              }
            });
          }).on('error', (err) => {
            console.error('[Update Check] Erro ao buscar update.json:', err);
          });
        } else {
          console.log(`[Update Check] Sistema atualizado (${currentVersion})`);
        }
      } catch (err) {
        console.error('[Update Check] Erro ao processar resposta:', err);
      }
    });
  }).on('error', (err) => {
    console.log('[Update Check] Erro ao verificar atualização:', err.message);
    // Não mostrar erro ao usuário, apenas logar
  });
}

/**
 * Compara duas versões usando semver (x.y.z)
 * Retorna: 1 se v1 > v2, -1 se v1 < v2, 0 se v1 === v2
 * NUNCA compara como string, sempre usa semver
 */
function compareVersionsSemver(v1, v2) {
  // Validar formato semver
  const semverRegex = /^\d+\.\d+\.\d+$/;
  if (!semverRegex.test(v1) || !semverRegex.test(v2)) {
    console.warn(`[Version Compare] Versão inválida: v1=${v1}, v2=${v2}. Usando fallback.`);
    // Fallback: tentar parse mesmo assim
  }
  
  // Dividir em partes numéricas (semver: MAJOR.MINOR.PATCH)
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);
  
  // Garantir 3 partes (MAJOR, MINOR, PATCH)
  while (parts1.length < 3) parts1.push(0);
  while (parts2.length < 3) parts2.push(0);
  
  // Comparar MAJOR primeiro
  if (parts1[0] !== parts2[0]) {
    return parts1[0] > parts2[0] ? 1 : -1;
  }
  
  // Se MAJOR igual, comparar MINOR
  if (parts1[1] !== parts2[1]) {
    return parts1[1] > parts2[1] ? 1 : -1;
  }
  
  // Se MINOR igual, comparar PATCH
  if (parts1[2] !== parts2[2]) {
    return parts1[2] > parts2[2] ? 1 : -1;
  }
  
  // Versões iguais
  return 0;
}

app.whenReady().then(() => {
  // Inicializar sistema de storage
  storageHandler.initializeStorage();
  
  createWindow();

  // Verificar atualizações após um pequeno delay (para não bloquear inicialização)
  setTimeout(() => {
    checkForUpdatesManual();
  }, 3000); // 3 segundos após o app estar pronto

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// Enviar evento will-quit para todos os renderers quando o app estiver fechando
app.on('before-quit', () => {
  const windows = BrowserWindow.getAllWindows();
  windows.forEach(win => {
    if (win && !win.isDestroyed()) {
      win.webContents.send('app-will-quit');
    }
  });
});

/**
 * Função para limpar dados do AppData do Electron
 * Remove apenas dados do usuário, mantendo arquivos do sistema
 */
async function clearAppData() {
  try {
    const userDataPath = app.getPath('userData');
    const localStoragePath = path.join(userDataPath, 'Local Storage');
    const sessionStoragePath = path.join(userDataPath, 'Session Storage');
    const cachePath = path.join(userDataPath, 'Cache');
    const codeCachePath = path.join(userDataPath, 'Code Cache');
    const blobStoragePath = path.join(userDataPath, 'blob_storage');
    const indexedDBPath = path.join(userDataPath, 'IndexedDB');
    const gpuCachePath = path.join(userDataPath, 'GPUCache');
    const serviceWorkerPath = path.join(userDataPath, 'Service Worker');
    
    const pathsToClear = [
      localStoragePath,
      sessionStoragePath,
      cachePath,
      codeCachePath,
      blobStoragePath,
      indexedDBPath,
      gpuCachePath,
      serviceWorkerPath,
    ];

    const clearedPaths = [];
    const errors = [];

    for (const dirPath of pathsToClear) {
      try {
        if (fs.existsSync(dirPath)) {
          await removeDirectory(dirPath);
          clearedPaths.push(dirPath);
        }
      } catch (error) {
        errors.push(`Erro ao limpar ${dirPath}: ${error.message}`);
      }
    }

    return {
      success: errors.length === 0,
      clearedPaths,
      errors,
    };
  } catch (error) {
    return {
      success: false,
      clearedPaths: [],
      errors: [`Erro geral ao limpar AppData: ${error.message}`],
    };
  }
}

/**
 * Remove diretório recursivamente
 */
async function removeDirectory(dirPath) {
  try {
    const stats = await stat(dirPath);
    
    if (stats.isDirectory()) {
      // Usar fs.promises.rm com opção recursive (método moderno)
      try {
        await fs.promises.rm(dirPath, { recursive: true, force: true });
      } catch (error) {
        // Fallback: método antigo se fs.promises.rm não estiver disponível
        if (error.code === 'ENOENT' || error.code === 'EBUSY') {
          // Ignorar se já não existe ou está em uso
          return;
        }
        // Tentar método manual como fallback
        const files = await readdir(dirPath);
        
        for (const file of files) {
          const filePath = path.join(dirPath, file);
          try {
            const fileStats = await stat(filePath);
            
            if (fileStats.isDirectory()) {
              await removeDirectory(filePath);
            } else {
              await unlink(filePath);
            }
          } catch (fileError) {
            // Ignorar erros de arquivos individuais
            if (fileError.code !== 'EBUSY' && fileError.code !== 'ENOENT' && isDev) {
              console.warn(`Erro ao remover ${filePath}:`, fileError.message);
            }
          }
        }
        
        // Tentar remover diretório vazio
        try {
          await fs.promises.rmdir(dirPath);
        } catch (rmdirError) {
          // Ignorar se não conseguir (pode estar em uso)
          if (rmdirError.code !== 'EBUSY' && rmdirError.code !== 'ENOENT' && rmdirError.code !== 'ENOTEMPTY') {
            throw rmdirError;
          }
        }
      }
    } else {
      await unlink(dirPath);
    }
  } catch (error) {
    // Ignorar erros de arquivos bloqueados (podem estar em uso)
    if (error.code !== 'EBUSY' && error.code !== 'ENOENT' && isDev) {
      // Log mas não lançar erro - continuar limpando outros diretórios
      console.warn(`Erro ao remover ${dirPath}:`, error.message);
    }
  }
}

// Handler IPC para limpar dados do AppData
ipcMain.handle('clear-app-data', async () => {
  return await clearAppData();
});

// Handlers IPC para controles de janela
ipcMain.handle('window-toggle-fullscreen', () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) {
    const isFullScreen = win.isFullScreen();
    win.setFullScreen(!isFullScreen);
    saveWindowState(win);
    return !isFullScreen;
  }
  return false;
});

ipcMain.handle('window-maximize', () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) {
    if (win.isMaximized()) {
      win.unmaximize();
    } else {
      win.maximize();
    }
    saveWindowState(win);
    return win.isMaximized();
  }
  return false;
});

ipcMain.handle('window-minimize', () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) {
    win.minimize();
  }
});

ipcMain.handle('window-close', () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) {
    win.close();
  }
});

ipcMain.handle('window-get-state', () => {
  const win = BrowserWindow.getFocusedWindow();
  if (win) {
    return {
      isMaximized: win.isMaximized(),
      isFullScreen: win.isFullScreen(),
      isMinimized: win.isMinimized(),
      size: win.getSize(),
      position: win.getPosition(),
    };
  }
  return null;
});

ipcMain.handle('window-set-zoom', (event, level) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) {
    win.webContents.setZoomLevel(Math.max(-3, Math.min(5, level)));
    return win.webContents.getZoomLevel();
  }
  return 0;
});

ipcMain.handle('window-get-zoom', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (win) {
    return win.webContents.getZoomLevel();
  }
  return 0;
});

// ========== HANDLERS DE ATUALIZAÇÃO OFFLINE ==========

// Validação de ambiente Electron (helper)
function validateElectronEnvironment() {
  if (!app || !app.isReady()) {
    return {
      valid: false,
      error: 'Aplicativo Electron não está pronto ou não está em ambiente Electron'
    };
  }
  return { valid: true };
}

// Detectar unidades removíveis (pendrives)
ipcMain.handle('update-detect-drives', async () => {
  const envCheck = validateElectronEnvironment();
  if (!envCheck.valid) {
    return { error: envCheck.error, drives: [] };
  }
  
  try {
    return await updateManager.detectRemovableDrives();
  } catch (error) {
    if (isDev) console.error('Erro ao detectar drives:', error);
    return { error: error.message, drives: [] };
  }
});

// Verificar atualização no pendrive
ipcMain.handle('update-check', async (event, drivePath) => {
  const envCheck = validateElectronEnvironment();
  if (!envCheck.valid) {
    return { available: false, error: envCheck.error };
  }
  
  try {
    const updateInfo = await updateManager.checkForUpdate(drivePath);
    if (!updateInfo) {
      return { available: false };
    }

    const currentVersion = updateManager.getCurrentVersion();
    const comparison = updateManager.compareVersions(updateInfo.version, currentVersion);

    return {
      available: comparison > 0,
      version: updateInfo.version,
      currentVersion: currentVersion,
      description: updateInfo.description,
      date: updateInfo.date,
      updatePath: updateInfo.updatePath,
      comparison: comparison // Incluir para debug
    };
  } catch (error) {
    if (isDev) console.error('Erro ao verificar atualização:', error);
    return { available: false, error: error.message };
  }
});

// Obter versão atual (compatível com offline e online)
ipcMain.handle('update-get-current-version', () => {
  try {
    // Tentar obter versão do updateManager primeiro (offline)
  const envCheck = validateElectronEnvironment();
    if (envCheck.valid) {
      try {
        const version = updateManager.getCurrentVersion();
        return version;
      } catch (error) {
        // Fallback para updater se updateManager falhar
        const version = updater.getCurrentVersionSync();
        return version;
      }
    } else {
      // Se ambiente não válido, tentar updater diretamente
      const version = updater.getCurrentVersionSync();
      return version;
    }
  } catch (error) {
    if (isDev) console.error('Erro ao obter versão atual:', error);
    return '2.0.0';
  }
});

// Criar backup antes da atualização
ipcMain.handle('update-create-backup', async () => {
  const envCheck = validateElectronEnvironment();
  if (!envCheck.valid) {
    return { success: false, error: envCheck.error };
  }
  
  try {
    const userDataPath = app.getPath('userData');
    const backupDir = path.join(userDataPath, 'backups');
    return await updateManager.createBackup(backupDir);
  } catch (error) {
    if (isDev) console.error('Erro ao criar backup:', error);
    return { success: false, error: error.message };
  }
});

// Aplicar atualização
ipcMain.handle('update-apply', async (event, updatePath) => {
  const envCheck = validateElectronEnvironment();
  if (!envCheck.valid) {
    return { success: false, error: envCheck.error };
  }
  
  try {
    // CRÍTICO: Validar versão antes de aplicar (prevenir downgrade)
    const updateInfo = await updateManager.checkForUpdate(path.dirname(updatePath));
    if (!updateInfo) {
      return { 
        success: false, 
        error: 'Não foi possível verificar informações da atualização' 
      };
    }
    
    const currentVersion = updateManager.getCurrentVersion();
    const comparison = updateManager.compareVersions(updateInfo.version, currentVersion);
    
    // Bloquear downgrade ou versão igual
    if (comparison <= 0) {
      const errorMsg = comparison === 0 
        ? `A versão ${updateInfo.version} é igual à versão atual. Não é necessário atualizar.`
        : `Não é permitido fazer downgrade. Versão atual: ${currentVersion}, Versão do pendrive: ${updateInfo.version}`;
      
      // Salvar log da tentativa de downgrade
      await updateManager.saveUpdateLog({
        type: 'update',
        status: 'error',
        previousVersion: currentVersion,
        newVersion: updateInfo.version,
        date: new Date().toISOString(),
        errors: [errorMsg],
        timestamp: Date.now()
      });
      
      return { 
        success: false, 
        error: errorMsg,
        blocked: true // Flag para indicar que foi bloqueado
      };
    }
    
    const appPath = app.getAppPath();
    const result = await updateManager.applyUpdate(updatePath, appPath);
    
    // Salvar log da atualização
    if (result.success) {
      const logData = {
        type: 'update',
        status: 'success',
        previousVersion: currentVersion,
        newVersion: result.newVersion || updateInfo.version,
        date: new Date().toISOString(),
        filesUpdated: result.filesUpdated,
        timestamp: Date.now()
      };
      await updateManager.saveUpdateLog(logData);
    } else {
      const logData = {
        type: 'update',
        status: 'error',
        previousVersion: currentVersion,
        newVersion: updateInfo.version,
        date: new Date().toISOString(),
        errors: result.errors,
        timestamp: Date.now()
      };
      await updateManager.saveUpdateLog(logData);
    }
    
    return result;
  } catch (error) {
    if (isDev) console.error('Erro ao aplicar atualização:', error);
    return { success: false, error: error.message };
  }
});

// Restaurar backup
ipcMain.handle('update-restore-backup', async (event, backupPath) => {
  const envCheck = validateElectronEnvironment();
  if (!envCheck.valid) {
    return { success: false, error: envCheck.error };
  }
  
  try {
    const appPath = app.getAppPath();
    const result = await updateManager.restoreBackup(backupPath, appPath);
    
    // Salvar log da restauração
    const logData = {
      type: 'restore',
      status: result.success ? 'success' : 'error',
      date: new Date().toISOString(),
      filesRestored: result.filesRestored,
      errors: result.errors,
      timestamp: Date.now()
    };
    await updateManager.saveUpdateLog(logData);
    
    return result;
  } catch (error) {
    if (isDev) console.error('Erro ao restaurar backup:', error);
    return { success: false, error: error.message };
  }
});

// Obter logs de atualização
ipcMain.handle('update-get-logs', async () => {
  const envCheck = validateElectronEnvironment();
  if (!envCheck.valid) {
    return { error: envCheck.error, logs: [] };
  }
  
  try {
    return await updateManager.readUpdateLogs();
  } catch (error) {
    if (isDev) console.error('Erro ao obter logs:', error);
    return [];
  }
});

// ========== HANDLERS DE ATUALIZAÇÃO ONLINE (GitHub Raw Content) ==========

// NOTA: Handler 'update-get-current-version' já está registrado acima (linha 541)
// Removido duplicado para evitar erro "Attempted to register a second handler"

// Verificar status online
ipcMain.handle('update-check-online-status', async () => {
  try {
    const isOnline = await updater.checkOnlineStatus();
    console.log('[IPC] Status online:', isOnline);
    return { online: isOnline };
  } catch (error) {
    console.error('[IPC] Erro ao verificar status online:', error);
    return { online: false, error: error.message };
  }
});

// Verificar atualizações online
ipcMain.handle('update-check-online', async () => {
  try {
    console.log('[IPC] Verificando atualizações...');
    const result = await updater.checkForUpdates();
    console.log('[IPC] Resultado da verificação:', result);
    return result;
  } catch (error) {
    console.error('[IPC] Erro ao verificar atualização:', error);
    return { 
      available: false, 
      online: false, 
      error: error.message || 'Erro ao verificar atualização' 
    };
  }
});

// ========== HANDLERS DE ATUALIZAÇÃO ONLINE PADRONIZADOS ==========

/**
 * Sistema de Atualização Manual Completo
 * Baixa ZIP, extrai e substitui arquivos da aplicação
 */

/**
 * Baixa arquivo ZIP da URL fornecida
 */
async function downloadZipFile(downloadUrl, filePath, onProgress) {
  return new Promise((resolve, reject) => {
    console.log('[Update] Iniciando download:', downloadUrl);
    console.log('[Update] Salvando em:', filePath);

    const url = new URL(downloadUrl);
    const client = url.protocol === 'https:' ? https : require('http');
    
    const file = fs.createWriteStream(filePath);
    let totalBytes = 0;
    let progressInterval = null;

    const req = client.get(url, (res) => {
      if (res.statusCode !== 200) {
        file.close();
        try {
          fs.unlinkSync(filePath);
        } catch (e) {}
        reject(new Error(`HTTP ${res.statusCode}: ${res.statusMessage}`));
        return;
      }

      totalBytes = parseInt(res.headers['content-length'] || '0', 10);
      console.log(`[Update] Tamanho do arquivo: ${(totalBytes / 1024 / 1024).toFixed(2)} MB`);

      // Se temos callback de progresso e tamanho total, calcular progresso periodicamente
      if (onProgress && totalBytes > 0) {
        progressInterval = setInterval(() => {
          try {
            const stats = fs.statSync(filePath);
            const downloadedBytes = stats.size;
            const percent = Math.min(100, Math.round((downloadedBytes / totalBytes) * 100));
            onProgress(percent);
          } catch (err) {
            // Ignorar erros ao ler estatísticas do arquivo
          }
        }, 500); // Atualizar a cada 500ms
      }

      // Pipe do stream de resposta para o arquivo
      res.pipe(file);

      // Quando o pipe terminar
      file.on('finish', () => {
        if (progressInterval) {
          clearInterval(progressInterval);
        }
        file.close();
        const finalStats = fs.statSync(filePath);
        console.log('[Update] ✅ Download concluído');
        if (onProgress) {
          onProgress(100);
        }
        resolve({
          success: true,
          filePath: filePath,
          size: finalStats.size
        });
      });

      // Tratar erros no stream de resposta
      res.on('error', (error) => {
        if (progressInterval) {
          clearInterval(progressInterval);
        }
        file.close();
        try {
          fs.unlinkSync(filePath);
        } catch (e) {}
        console.error('[Update] ❌ Erro no stream de resposta:', error);
        reject(new Error(`Erro no download: ${error.message}`));
      });
    });

    // Tratar erros na requisição
    req.on('error', (error) => {
      if (progressInterval) {
        clearInterval(progressInterval);
      }
      file.close();
      try {
        fs.unlinkSync(filePath);
      } catch (e) {}
      console.error('[Update] ❌ Erro na requisição:', error);
      reject(new Error(`Erro no download: ${error.message}`));
    });

    // Tratar erros no arquivo
    file.on('error', (error) => {
      if (progressInterval) {
        clearInterval(progressInterval);
      }
      file.close();
      try {
        fs.unlinkSync(filePath);
      } catch (e) {}
      console.error('[Update] ❌ Erro ao escrever arquivo:', error);
      reject(new Error(`Erro ao salvar arquivo: ${error.message}`));
    });

    // Timeout
    req.setTimeout(300000, () => { // 5 minutos
      if (progressInterval) {
        clearInterval(progressInterval);
      }
      req.destroy();
      file.close();
      try {
        fs.unlinkSync(filePath);
      } catch (e) {}
      reject(new Error('Timeout no download (5 minutos)'));
    });
  });
}

/**
 * Copia arquivos recursivamente
 */
async function copyRecursive(src, dest) {
  const stats = await fs.promises.stat(src);
  
  if (stats.isDirectory()) {
    // Criar diretório de destino se não existir
    await fs.promises.mkdir(dest, { recursive: true });
    
    // Ler conteúdo do diretório
    const entries = await fs.promises.readdir(src);
    
    // Copiar cada entrada
    for (const entry of entries) {
      const srcPath = path.join(src, entry);
      const destPath = path.join(dest, entry);
      await copyRecursive(srcPath, destPath);
    }
  } else {
    // Copiar arquivo
    await fs.promises.copyFile(src, dest);
  }
}

/**
 * Obtém o diretório de instalação da aplicação
 */
function getAppInstallDir() {
  if (isDev) {
    // Em desenvolvimento, usar o diretório do projeto
    return path.join(__dirname, '..');
  } else {
    // Em produção, usar process.resourcesPath (onde está o app.asar)
    // Em Windows, o executável está em process.execPath
    // O diretório de recursos está em process.resourcesPath
    return process.resourcesPath;
  }
}

/**
 * Obtém o caminho do executável da aplicação
 */
function getAppExecutablePath() {
  if (isDev) {
    return process.execPath; // Em dev, usar o executável do Electron
  } else {
    // Em produção, process.execPath aponta para o .exe
    return process.execPath;
  }
}

/**
 * Valida estrutura do ZIP extraído
 * Deve conter: executável do app e pasta resources/
 */
async function validateZipStructure(extractDir) {
  const contents = await fs.promises.readdir(extractDir);
  console.log('[Update] 📋 Validando estrutura do ZIP:', contents);

  // Verificar se há subpasta com versão (ex: update-2.0.9/)
  let rootDir = extractDir;
  for (const item of contents) {
    const itemPath = path.join(extractDir, item);
    const stats = await fs.promises.stat(itemPath);
    
    // Se encontrar uma pasta com padrão update-X.X.X, usar ela como raiz
    if (stats.isDirectory() && /^update-\d+\.\d+\.\d+$/i.test(item)) {
      console.log('[Update] ⚠️ Encontrada subpasta de versão, usando como raiz:', item);
      rootDir = itemPath;
      break;
    }
  }

  // Verificar estrutura esperada
  const rootContents = await fs.promises.readdir(rootDir);
  const hasResources = rootContents.some(item => {
    const itemPath = path.join(rootDir, item);
    try {
      const stats = fs.statSync(itemPath);
      return stats.isDirectory() && item.toLowerCase() === 'resources';
    } catch {
      return false;
    }
  });

  // Verificar se há executável ou estrutura de app Electron
  const hasAppStructure = rootContents.some(item => {
    const itemPath = path.join(rootDir, item);
    try {
      const stats = fs.statSync(itemPath);
      // Pode ser executável .exe ou estrutura de app (resources/, app.asar, etc)
      return stats.isFile() && item.endsWith('.exe') || 
             (stats.isDirectory() && (item.toLowerCase() === 'resources' || item.toLowerCase() === 'dist'));
    } catch {
      return false;
    }
  });

  if (!hasResources && !hasAppStructure) {
    throw new Error('Estrutura do ZIP inválida: deve conter executável do app e pasta resources/ ou estrutura de app Electron');
  }

  console.log('[Update] ✅ Estrutura do ZIP validada');
  return rootDir;
}

/**
 * Cria script .bat para Windows que:
 * 1. Aguarda o app fechar
 * 2. Copia os arquivos novos sobre os antigos
 * 3. Reabre o aplicativo
 */
async function createUpdateBatchScript(extractDir, appInstallDir, appExecutable) {
  const userDataPath = app.getPath('userData');
  const updatesDir = path.join(userDataPath, 'updates');
  await fs.promises.mkdir(updatesDir, { recursive: true });
  
  const batPath = path.join(updatesDir, 'update.bat');
  const appProcessName = path.basename(appExecutable, '.exe');
  
  // Criar script .bat
  const batContent = `@echo off
REM ============================================
REM Script de atualização automática - Smart Tech Rolândia
REM IMPORTANTE: Este script NÃO toca nos dados do cliente
REM Dados do cliente estão em: C:\\Users\\Public\\SmartTechRolandia\\data\\
REM Este script atualiza APENAS: process.resourcesPath (arquivos do app)
REM ============================================
echo [Update] Aguardando aplicativo fechar...

REM Aguardar até que o processo do app não esteja mais em execução
:wait_loop
tasklist /FI "IMAGENAME eq ${appProcessName}.exe" 2>NUL | find /I /N "${appProcessName}.exe">NUL
if "%ERRORLEVEL%"=="0" (
  timeout /t 1 /nobreak >NUL
  goto wait_loop
)

echo [Update] Aplicativo fechado. Instalando atualização...
echo [Update] NOTA: Dados do cliente estao protegidos e nao serao alterados.

REM ============================================
REM ETAPA 1: COPIAR ARQUIVOS NOVOS E REMOVER OBSOLETOS
REM IMPORTANTE: Robocopy copia APENAS para o diretório de instalação do app
REM NÃO toca em: C:\\Users\\Public\\SmartTechRolandia\\data\\ (dados do cliente)
REM ============================================
echo [Update] Copiando arquivos novos e removendo obsoletos...

REM Usar robocopy para cópia robusta (Windows)
REM /E = copiar subdiretórios, incluindo vazios
REM /IS = incluir arquivos do mesmo tamanho
REM /IT = incluir arquivos com mesmo timestamp
REM /PURGE = remover arquivos/diretórios no destino que não existem na origem
REM /R:3 = tentar 3 vezes em caso de erro
REM /W:1 = esperar 1 segundo entre tentativas
REM /NFL = não listar arquivos
REM /NDL = não listar diretórios
REM /NP = não mostrar progresso
REM /XD = excluir diretórios específicos (evitar remover dados do usuário)
robocopy "${extractDir.replace(/\//g, '\\')}" "${appInstallDir.replace(/\//g, '\\')}" /E /IS /IT /PURGE /R:3 /W:1 /NFL /NDL /NP /XD "resources\\app.asar.unpacked\\electron" 2>NUL

REM Robocopy retorna códigos de saída:
REM 0 = nenhum arquivo copiado (sem mudanças)
REM 1 = arquivos copiados com sucesso
REM 2-7 = erros ou avisos (aceitáveis)
REM 8+ = erros graves
if %ERRORLEVEL% GTR 7 (
  echo [Update] ERRO: Falha ao copiar arquivos (código: %ERRORLEVEL%)
  pause
  exit /b 1
)

echo [Update] Arquivos copiados e obsoletos removidos com sucesso!

REM ============================================
REM ETAPA 3: LIMPAR ARQUIVOS TEMPORÁRIOS
REM ============================================
echo [Update] Limpando arquivos temporários...

REM Limpar diretório temporário de extração
rmdir /S /Q "${extractDir.replace(/\//g, '\\')}" 2>NUL

REM Limpar lista temporária
if exist "%TEMP_LIST%" del "%TEMP_LIST%" 2>NUL

REM ============================================
REM ETAPA 4: REINICIAR APLICATIVO
REM ============================================
echo [Update] Reiniciando aplicativo...
start "" "${appExecutable.replace(/\//g, '\\')}"

REM ============================================
REM ETAPA 5: LIMPAR SCRIPT .BAT
REM ============================================
REM Aguardar um pouco antes de remover o script
timeout /t 2 /nobreak >NUL
del "%~f0"

echo [Update] Atualização concluída com sucesso!
`;

  await fs.promises.writeFile(batPath, batContent, 'utf8');
  console.log('[Update] ✅ Script .bat criado:', batPath);
  return batPath;
}

/**
 * Função auxiliar: Baixa, extrai e instala atualização (SISTEMA COMPLETO)
 * Usa script .bat para Windows que aguarda app fechar, copia arquivos e reinicia
 */
async function handleUpdateDownloadAndInstall(event, downloadUrl) {
  if (!downloadUrl) {
    console.error('[Update] ❌ URL de download não fornecida');
    return { 
      success: false, 
      error: 'URL de download não fornecida' 
    };
  }

  // Bloquear em modo dev (apenas para produção)
  if (isDev) {
    console.warn('[Update] ⚠️ Modo dev detectado - atualização automática desabilitada');
    return {
      success: false,
      error: 'Atualização automática disponível apenas no aplicativo instalado (EXE)'
    };
  }

  // Verificar se está no Windows
  if (process.platform !== 'win32') {
    console.error('[Update] ❌ Sistema de atualização automática disponível apenas no Windows');
    return {
      success: false,
      error: 'Sistema de atualização automática disponível apenas no Windows'
    };
  }

  const userDataPath = app.getPath('userData');
  const tempDir = path.join(userDataPath, 'updates', 'temp');
  const zipPath = path.join(tempDir, `update-${Date.now()}.zip`);
  const extractDir = path.join(tempDir, 'extracted');

  try {
    // ============================================
    // ETAPA 0: BACKUP AUTOMÁTICO DOS DADOS DO CLIENTE
    // ============================================
    console.log('[Update] 💾 Criando backup automático dos dados do cliente...');
    event.sender.send('update-status', { status: 'backing-up', message: 'Criando backup dos dados...' });
    
    try {
      // Importar storage-handler para acessar funções de backup
      const storageInfo = await storageHandler.getStorageInfo();
      if (storageInfo.exists && storageInfo.path) {
        const dataPath = storageInfo.path;
        const backupPath = dataPath.replace('database.json', `database-backup-pre-update-${Date.now()}.json`);
        
        // Copiar arquivo de dados para backup
        if (fs.existsSync(dataPath)) {
          await fs.promises.copyFile(dataPath, backupPath);
          console.log('[Update] ✅ Backup dos dados criado:', backupPath);
          console.log('[Update] 📂 Dados protegidos em:', dataPath);
        }
      }
    } catch (backupError) {
      console.warn('[Update] ⚠️ Erro ao criar backup (não crítico):', backupError.message);
      // Não bloquear atualização se backup falhar
    }

    // Criar diretórios temporários
    await fs.promises.mkdir(tempDir, { recursive: true });
    await fs.promises.mkdir(extractDir, { recursive: true });

    console.log('[Update] 📥 Iniciando download...');
    event.sender.send('update-status', { status: 'downloading', message: 'Baixando atualização...' });
    event.sender.send('update-download-progress', 0);

    // 1. Baixar ZIP
    await downloadZipFile(downloadUrl, zipPath, (percent) => {
      event.sender.send('update-download-progress', percent);
    });

    console.log('[Update] 📦 Extraindo ZIP...');
    event.sender.send('update-status', { status: 'extracting', message: 'Extraindo arquivos...' });
    event.sender.send('update-download-progress', -1); // -1 indica "extraindo"

    // 2. Extrair ZIP
    await extractZip(zipPath, { dir: extractDir });
    console.log('[Update] ✅ ZIP extraído');

    // 3. Validar estrutura do ZIP
    const validatedRootDir = await validateZipStructure(extractDir);

    // 4. Identificar diretórios
    const appInstallDir = getAppInstallDir();
    const appExecutable = getAppExecutablePath();
    console.log('[Update] 📂 Diretório de instalação:', appInstallDir);
    console.log('[Update] 📂 Executável:', appExecutable);

    // 5. Criar script .bat para atualização
    console.log('[Update] 📝 Criando script de atualização...');
    event.sender.send('update-status', { status: 'preparing', message: 'Preparando instalação...' });
    
    const batPath = await createUpdateBatchScript(validatedRootDir, appInstallDir, appExecutable);

    // 6. Limpar ZIP (manter extraído para o script .bat)
    try {
      await fs.promises.unlink(zipPath);
      console.log('[Update] ✅ ZIP removido');
    } catch (cleanupError) {
      console.warn('[Update] ⚠️ Erro ao remover ZIP:', cleanupError);
    }

    // 7. Executar script .bat e fechar app
    console.log('[Update] 🚀 Executando script de atualização...');
    event.sender.send('update-status', { status: 'installing', message: 'Instalando atualização...' });
    event.sender.send('update-download-progress', 95);

    // Executar script .bat em background (elevado se necessário)
    const batProcess = spawn('cmd.exe', ['/c', batPath], {
      detached: true,
      stdio: 'ignore',
      shell: true
    });
    batProcess.unref(); // Permitir que o processo pai termine

    // Aguardar um pouco para garantir que o script iniciou
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Fechar aplicativo (o script .bat aguardará e copiará os arquivos)
    console.log('[Update] 🔄 Fechando aplicativo para aplicar atualização...');
    event.sender.send('update-status', { status: 'restarting', message: 'Reiniciando aplicativo...' });
    event.sender.send('update-download-progress', 100);

    // Dar tempo para o frontend atualizar antes de fechar
    setTimeout(() => {
      app.quit();
    }, 500);

    return {
      success: true,
      message: 'Atualização será aplicada após o aplicativo fechar. O aplicativo será reiniciado automaticamente.',
      requiresRestart: true
    };

  } catch (error) {
    console.error('[Update] ❌ Erro durante atualização:', error);
    event.sender.send('update-status', { status: 'error', message: error.message });
    
    // Limpar arquivos temporários em caso de erro
    try {
      await fs.promises.rm(tempDir, { recursive: true, force: true });
    } catch (cleanupError) {
      console.warn('[Update] ⚠️ Erro ao limpar após erro:', cleanupError);
    }

    return {
      success: false,
      error: error.message || 'Erro desconhecido durante atualização'
    };
  }
}

/**
 * Handler principal: Baixa, extrai e instala atualização
 */
ipcMain.handle('update-start-download', async (event, downloadUrl) => {
  return await handleUpdateDownloadAndInstall(event, downloadUrl);
});

// Alias para compatibilidade (update-download → update-start-download)
ipcMain.handle('update-download', async (event, downloadUrl) => {
  return await handleUpdateDownloadAndInstall(event, downloadUrl);
});

/**
 * ============================================
 * MODO 1 — UPDATE ASSISTIDO
 * ============================================
 * O app apenas verifica versão e baixa o ZIP
 * NÃO extrair automaticamente
 * NÃO substituir arquivos do app
 * O usuário executa ATUALIZAR.bat manualmente
 * ============================================
 */

/**
 * Baixa atualização usando arrayBuffer (sem pipe)
 * Salva em Downloads e abre a pasta
 * Suporta redirects HTTP 301, 302, 307, 308
 */
async function baixarAtualizacaoAssistida(downloadUrl) {
  const downloadDir = app.getPath('downloads');
  const zipPath = path.join(downloadDir, 'update.zip');

  console.log('[Update Assistido] 📥 Iniciando download...');
  console.log('[Update Assistido] URL:', downloadUrl);
  console.log('[Update Assistido] Destino:', zipPath);

  // Verificar se fetch está disponível (Node.js 18+ ou Electron com fetch)
  if (typeof globalThis.fetch !== 'undefined') {
    try {
      console.log('[Update Assistido] Usando fetch (com suporte a redirects)...');
      
      // Criar AbortController para timeout (compatível com versões antigas)
      let abortController;
      let timeoutId;
      try {
        abortController = new AbortController();
        timeoutId = setTimeout(() => {
          abortController.abort();
        }, 300000); // 5 minutos
      } catch (e) {
        // Se AbortController não estiver disponível, usar sem timeout
        abortController = null;
      }
      
      const fetchOptions = { 
        redirect: 'follow'
      };
      
      if (abortController) {
        fetchOptions.signal = abortController.signal;
      }
      
      const res = await globalThis.fetch(downloadUrl, fetchOptions);
      
      // Limpar timeout se download completar
      if (timeoutId) {
        clearTimeout(timeoutId);
      }

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }

      const arrayBuffer = await res.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      fs.writeFileSync(zipPath, buffer);
      
      console.log('[Update Assistido] ✅ Download concluído');
      console.log('[Update Assistido] 📁 Arquivo salvo em:', zipPath);
      console.log(`[Update Assistido] Tamanho: ${(buffer.length / 1024 / 1024).toFixed(2)} MB`);
      
      // Abrir pasta do Downloads
      shell.showItemInFolder(zipPath);
      
      return {
        success: true,
        filePath: zipPath,
        size: buffer.length
      };
    } catch (error) {
      // Limpar timeout em caso de erro
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      
      // Se fetch falhar, tentar método alternativo
      if (error.name === 'AbortError' || error.message.includes('timeout')) {
        console.warn('[Update Assistido] ⚠️ Timeout no fetch, tentando método alternativo');
      } else {
        console.warn('[Update Assistido] ⚠️ Fetch falhou, tentando método alternativo:', error.message);
      }
    }
  }

  // Método alternativo: usar https/http com suporte a redirects manual
  return new Promise((resolve, reject) => {
    let currentUrl = downloadUrl;
    let redirectCount = 0;
    const maxRedirects = 10;

    const download = (url) => {
      if (redirectCount > maxRedirects) {
        reject(new Error('Muitos redirects (possível loop)'));
        return;
      }

      const urlObj = new URL(url);
      const client = urlObj.protocol === 'https:' ? https : http;

      const chunks = [];
      let totalBytes = 0;

      const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || (urlObj.protocol === 'https:' ? 443 : 80),
        path: urlObj.pathname + urlObj.search,
        method: 'GET',
        headers: {
          'User-Agent': 'SmartTechRolandia-Updater/1.0'
        }
      };

      const req = client.get(options, (res) => {
        // Verificar se é redirect (301, 302, 307, 308)
        if (res.statusCode === 301 || res.statusCode === 302 || 
            res.statusCode === 307 || res.statusCode === 308) {
          const location = res.headers.location;
          if (!location) {
            reject(new Error(`HTTP ${res.statusCode}: Redirect sem header Location`));
            return;
          }

          // Resolver URL relativa
          const redirectUrl = new URL(location, url).href;
          console.log(`[Update Assistido] 🔄 Redirect ${res.statusCode} para: ${redirectUrl}`);
          redirectCount++;
          
          // Seguir redirect
          download(redirectUrl);
          return;
        }

        // Se não for 200, rejeitar
        if (res.statusCode !== 200) {
          reject(new Error(`HTTP ${res.statusCode}: ${res.statusMessage}`));
          return;
        }

        totalBytes = parseInt(res.headers['content-length'] || '0', 10);
        console.log(`[Update Assistido] Tamanho: ${(totalBytes / 1024 / 1024).toFixed(2)} MB`);

        res.on('data', (chunk) => {
          chunks.push(chunk);
        });

        res.on('end', () => {
          try {
            // Converter chunks para Buffer
            const buffer = Buffer.concat(chunks);
            fs.writeFileSync(zipPath, buffer);
            
            console.log('[Update Assistido] ✅ Download concluído');
            console.log('[Update Assistido] 📁 Arquivo salvo em:', zipPath);
            
            // Abrir pasta do Downloads
            shell.showItemInFolder(zipPath);
            
            resolve({
              success: true,
              filePath: zipPath,
              size: buffer.length
            });
          } catch (error) {
            console.error('[Update Assistido] ❌ Erro ao salvar arquivo:', error);
            reject(new Error(`Erro ao salvar arquivo: ${error.message}`));
          }
        });

        res.on('error', (error) => {
          console.error('[Update Assistido] ❌ Erro no stream:', error);
          reject(new Error(`Erro no download: ${error.message}`));
        });
      });

      req.on('error', (error) => {
        console.error('[Update Assistido] ❌ Erro na requisição:', error);
        reject(new Error(`Erro no download: ${error.message}`));
      });

      req.setTimeout(300000, () => { // 5 minutos
        req.destroy();
        reject(new Error('Timeout no download (5 minutos)'));
      });
    };

    // Iniciar download
    download(currentUrl);
  });
}

/**
 * Handler IPC para download assistido
 */
ipcMain.handle('update-download-assistido', async (event, downloadUrl) => {
  try {
    const result = await baixarAtualizacaoAssistida(downloadUrl);
    return result;
  } catch (error) {
    console.error('[Update Assistido] ❌ Erro:', error);
    return {
      success: false,
      error: error.message || 'Erro desconhecido'
    };
  }
});

// Handlers alternativos (mantidos para compatibilidade, mas não usados no preload.js)
// update-download-online: método alternativo de download (não usado)
// update-apply-online: método alternativo de aplicação (não usado)

// Instalar atualização (padronizado)
ipcMain.handle('update-install', async (event, downloadPath) => {
  try {
    console.log('[IPC] Instalando atualização:', downloadPath);
    const result = await updater.applyUpdate(downloadPath);
    
    // Salvar log da atualização
    const currentVersion = updater.getCurrentVersionSync();
    const logData = {
      type: 'update',
      status: result.success ? 'success' : 'error',
      previousVersion: currentVersion,
      newVersion: result.newVersion || 'desconhecida',
      date: new Date().toISOString(),
      source: 'online',
      timestamp: Date.now()
    };
    
    // Tentar salvar log (se updateManager tiver essa função)
    try {
      if (updateManager.saveUpdateLog) {
        await updateManager.saveUpdateLog(logData);
      }
    } catch (logError) {
      console.warn('[IPC] Erro ao salvar log:', logError);
    }
    
    console.log('[IPC] Atualização instalada:', result);
    return result;
  } catch (error) {
    console.error('[IPC] Erro ao instalar atualização:', error);
    return { success: false, error: error.message };
  }
});

// ========== HANDLERS DE CONTROLE DE APLICATIVO ==========

// Reiniciar aplicativo
ipcMain.handle('app-restart', () => {
  try {
    console.log('[IPC] Reiniciando aplicativo...');
    app.relaunch();
    app.exit(0);
    return { success: true };
  } catch (error) {
    console.error('[IPC] Erro ao reiniciar aplicativo:', error);
    return { success: false, error: error.message };
  }
});

// Fechar aplicativo
ipcMain.handle('app-quit', () => {
  try {
    console.log('[IPC] Fechando aplicativo...');
    app.quit();
    return { success: true };
  } catch (error) {
    console.error('[IPC] Erro ao fechar aplicativo:', error);
    return { success: false, error: error.message };
  }
});

// ========== HANDLERS DE PERSISTÊNCIA DE DADOS ==========

// Salvar dados em arquivo permanente
ipcMain.handle('storage-save', async (event, data) => {
  try {
    return storageHandler.saveData(data);
  } catch (error) {
    if (isDev) console.error('Erro ao salvar dados:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// Carregar dados do arquivo permanente
ipcMain.handle('storage-load', async () => {
  try {
    return storageHandler.loadData();
  } catch (error) {
    if (isDev) console.error('Erro ao carregar dados:', error);
    return {
      success: false,
      error: error.message,
      data: null
    };
  }
});

// Limpar todos os dados
ipcMain.handle('storage-clear', async () => {
  try {
    return storageHandler.clearData();
  } catch (error) {
    if (isDev) console.error('Erro ao limpar dados:', error);
    return {
      success: false,
      error: error.message
    };
  }
});

// Obter informações sobre o storage
ipcMain.handle('storage-info', async () => {
  try {
    return storageHandler.getStorageInfo();
  } catch (error) {
    if (isDev) console.error('Erro ao obter info do storage:', error);
    return {
      error: error.message
    };
  }
});

